# Todo items

1. shows your todo list.
2. Todo's can be modified and deleted.
3. todo's can be easily added.

## Running Locally

1: Clone/unzip the project.
2: Run npm install in the root directory to get all of the dependencies.

3: Run npm start
